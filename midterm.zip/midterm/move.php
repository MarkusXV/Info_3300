<?php
session_start();

$direction_random = random_int(1,10);
if ($direction_random < 6){
    $_SESSION['actual_direction'] = 'Left';
}
else {
    $_SESSION['actual_direction'] = 'Right';
}

$_SESSION['user_guess'] = filter_input(INPUT_GET, 'user_guess');

header('Location: index.php');
