<?php
session_start();

$user_guess_display = "";
$actual_direction_display = "";
$result = "";

if ( isset($_SESSION['user_guess']) && isset($_SESSION['actual_direction'])){
    $user_guess_display = 'Your guess was ' . $_SESSION['user_guess'] . '</br>';
    $actual_direction_display = 'The actual direction was ' . $_SESSION['actual_direction'] . '</br>';

    if (strtolower($_SESSION['user_guess']) ==  strtolower($_SESSION['actual_direction'])){
        $result = "<div id='result'>Way to go, you guessed it!</div>";
    }
    else {
        $result = "<div id='result'>Good try, do you want to try again?</div>";
    }

}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css"/>
    <title>RoboMovers Peter</title>
</head>
<body>
    <h1>Guess the Robot's Movement (Left/Right)</h1>
    <div id="page_content">
    <?php if ( isset($_SESSION['user_guess']) && isset($_SESSION['actual_direction'])) : 
        echo $user_guess_display;
        echo $actual_direction_display;
        echo $result;
    endif;?>
        <form method="get" action="move.php">
        <input type="text" name="user_guess" value= <?php echo $_SESSION['user_guess'] ?>>
        <input type="submit" value="Guess"><br>
        </form>
    </div>
</body>
</html>