<?php
include 'view/header.php';
?>
<h1>Add Gear</h1>
    <form action="/individual_project/index.php?action=insert_gear" method="POST">
        
    <table class="my-3">
            <tr >
                <td class="pe-2">Gear Name: </td>
                <td><input type="text" name="gear_name"></input></td>
            </tr>
            <tr>
                <td class="pe-2">Gear Description: </td>
                <td><input type="text" name="gear_description"></input></td>
            </tr>
            <tr>
                <td class="pe-2">Gear Category: </td>
                <td><input type="text" name="gear_category"></input></td>
            </tr>
            <tr>
                <td class="pe-2">Gear Manufacturer: </td>
                <td><input type="text" name="gear_manufacturer"></input></td>
            </tr>
            <tr>
                <td><input type="submit" value="submit" /></td>
            </tr>
        </table>
    </form>
       
<?php include 'view/footer.php'; ?>