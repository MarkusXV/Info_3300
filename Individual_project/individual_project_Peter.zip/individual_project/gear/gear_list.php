<?php
include 'view/header.php';

if (!isset($message)){
    $message = "";
}

?>
<h1>All Gear</h1>
    <p><?php echo $message?></p>
    <a href="index.php?action=create_gear" class='btn btn-warning mb-2'>Add Gear</a>
       <table class="table">
        <thead>
            <tr> 
                <td>Name</td>
                <td>Description</td>
                <td>Category</td>
                <td>Manufacturer</td>
            </tr>
        </thead>
            <tbody>
       <?php foreach ($gear as $gear) :?>
           <tr>
            <td><?=$gear['gear_name']?></td>
            <td><?=$gear['gear_description']?></td>
            <td><?=$gear['gear_category']?></td>
            <td><?=$gear['gear_manufacturer']?></td>
           </tr>
       <?php endforeach; ?>
       </tbody>
       </table>
       
<?php include 'view/footer.php'; ?>