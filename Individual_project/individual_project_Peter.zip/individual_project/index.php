<?php
session_start();
require('model/gear_db.php');

$action = filter_input(INPUT_POST, 'action');
if ($action == NULL) {
   $action = filter_input(INPUT_GET, 'action');
   if ($action == NULL) {
       $action = 'read_gear';
   }
}

if ($action == 'read_gear') {
   $gear = read_gear();
   include('gear/gear_list.php');
}

else if($action == 'create_gear'){
   include('gear/gear_add.php');
}

else if($action == 'insert_gear'){
    $gear_name = filter_input(INPUT_POST, 'gear_name');
    $gear_description = filter_input(INPUT_POST, 'gear_description');
    $gear_category = filter_input(INPUT_POST, 'gear_category');
    $gear_manufacturer = filter_input(INPUT_POST, 'gear_manufacturer');
    create_gear($gear_name, $gear_description, $gear_category, $gear_manufacturer);
    $gear = read_gear();
    $message = "Gear Added";
    include('gear/gear_list.php');
}