
<footer>  
  <a href="/individual_project/index.php" class="btn btn-warning">Home</a>
  <br>
  <p class="copyright">&copy; <?php echo date("Y"); ?> The Gear Loan System</p>
</footer>
</body>
</html>
