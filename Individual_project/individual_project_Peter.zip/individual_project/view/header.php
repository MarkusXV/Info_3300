<?php
   header('Content-Type: text/html; charset=iso-8859-1');
?>
<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
  <title>Gear Loan System</title>
  <link rel="stylesheet" type="text/css" href="/individual_project/styles.css">
  <link href="/individual_project/lib/css/bootstrap.min.css" rel="stylesheet">
</head>

<!-- the body section -->
<body  class="my-4 mx-5">
<header><h1>Gear Loan System</h1></header>
<hr>
